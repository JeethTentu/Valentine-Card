ENGLISH
NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
- Paypal account for donation : https://paypal.me/yugopriyatmoko

- Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/you-are-my-valentine-2/ref/236575/

- If you need an extended license or corporate license, please contact us
holydie.studio@gmail.com

Thank you.
====================
INDONESIA ( HARAP DIBACA !!! ):
Halo, terima kasih sudah mendownload font ini, Perlu diketahui bahwa :
- Font ini hanya untuk penggunaan PERSONAL saja, tidak untuk digunakan kebutuhan KOMERSIAL
- Jika anda ingin menggunakannya untuk kebutuhan komersial, anda harus membeli lisensi komersialnya terlebih dahulu
- Menggunakan font ini untuk kepentingan Komersial TANPA IZIN dari kami merupakan PELANGGARAN HAK CIPTA, dan akan kami kenakan biaya EXTENDED LICENSE.

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font diatas
Informasi tentang Lisensi, silahkan hubungi kami holydie.studio@gmail.com
Terimakasih